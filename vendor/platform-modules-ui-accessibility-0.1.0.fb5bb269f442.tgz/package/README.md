# @platform-modules/ui-accessibility

Framework-neutral accessibility preferences and a native HTML dialog. The package improves presentation choices; it does not certify a website, replace a screen reader, repair application semantics or make third-party content accessible.

## Install and mount

Import the stylesheet explicitly and mount after the document body exists:

```ts
import '@platform-modules/ui-accessibility/styles.css'
import { mountAccessibility } from '@platform-modules/ui-accessibility/browser'

const controls = mountAccessibility({
  document,
  locale: 'en',
  storageKey: 'your-project.accessibility.v1',
  statementHref: '/accessibility',
  reportHref: '/accessibility#report',
})

// On component unmount or before a client-side document swap:
controls.destroy()
```

Keep a permanent accessibility-statement link in the host navigation. The mount can throw `AccessibilityError` with `INVALID_OPTIONS`, `NO_WINDOW` or `UNSUPPORTED_DIALOG`. Use `isAccessibilityError` for structural checks across package instances. Importing the JavaScript is safe during server rendering; calling mount requires a live browser document with native dialog support.

The controller exposes `open`, `close`, `getPreferences`, `setPreferences`, `reset` and `destroy`. Repeated mounting replaces the previous instance instead of accumulating controls or listeners. Native dialog supplies Escape and focus containment; the controller supplies initial heading focus and return to the invoker.

## Preferences and persistence

Text size: 100, 112, 125, 150, 175 or 200 percent. Contrast: default, white on black, black on white or yellow on black. Independent settings cover text spacing, readable font, underlined links, strong focus, reduced motion, hiding decorative images, a larger pointer and a reading line/window. Users can change launcher position and choose English, Hebrew or Spanish for the panel without changing the host language.

Preferences are a validated, versioned localStorage record, confined to the current origin. There is no network request, account synchronization, tracking or disability profile. Storage failure leaves controls usable and shows a session-only notice. Reset removes only this package's storage record; operating-system preferences continue to apply. Images are not color-inverted and meaningful images are not hidden.

The pure `./preferences` API provides `DEFAULT_PREFERENCES`, `normalizePreferences`, `parsePreferences`, `serializePreferences` and the corresponding TypeScript types. Unknown fields, inherited properties, accessors, unsupported versions and unsupported values cannot become CSS or DOM settings.

## Host obligations

Use root-relative typography for text enlargement, real labels, meaningful alternatives, keyboard-operable controls, accessible status/error feedback and responsive layouts. Do not use the panel as an excuse to leave the default experience inaccessible. Imported styles include an always-visible keyboard focus treatment and operating-system reduced-motion support; enhanced presentation modes are opt-in. Motion reduction pauses currently playing autoplay video, but cannot guarantee stopping all animated images or third-party media.

Brand customization uses `--a11y-panel-background`, `--a11y-panel-foreground`, `--a11y-panel-muted`, `--a11y-panel-border`, `--a11y-panel-accent` and `--a11y-launcher-z`. Validate contrast after changing these tokens. The JavaScript has no import-time side effects; the stylesheet is intentionally marked side-effectful so bundlers retain explicit CSS imports.

Publish a truthful host-specific statement and usable reporting route. Complete manual assistive-technology, content, media, third-party and workflow evaluation before claiming conformance. Legal applicability and organizational duties are separate from the settings controls.

## Verification

Co-located tests exercise normalization, versioning, denied storage, native control labels, language/direction, reset, cleanup and SSR imports. jsdom dialog stubs test controller wiring only; real native focus containment, Escape, browser colors and reflow require the browser acceptance fixture.
